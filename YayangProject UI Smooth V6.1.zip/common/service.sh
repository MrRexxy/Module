#!/system/bin/sh

============================================================

YAYANG PROJECT - OVER POWER MODE v7.1

ADAPTIVE FULL POWER ENGINE

Android 10-16

Magisk | KernelSU | APatch

Qualcomm | MediaTek | Exynos | Unisoc

MODES:

FULL_POWER  = game / high load

PERFORMANCE = normal active usage

CHARGING    = charging optimization

COOL        = high temperature protection

============================================================

MODDIR=${0%/*}
LOGFILE="$MODDIR/overpower_v71.log"
STATEFILE="$MODDIR/current_mode"

------------------------------------------------------------

LOGGER

------------------------------------------------------------

log_msg() {
echo "[$(date '+%Y-%m-%d %H:%M:%S')] $" >> "$LOGFILE"
log -p i -t YayangProject "$" 2>/dev/null
}

------------------------------------------------------------

SAFE SYSFS WRITER

------------------------------------------------------------

write_node() {
NODE="$1"
VALUE="$2"

[ -e "$NODE" ] || return 1

echo "$VALUE" > "$NODE" 2>/dev/null

}

------------------------------------------------------------

SAFE PROPERTY SETTER

------------------------------------------------------------

set_prop() {
if command -v resetprop >/dev/null 2>&1; then
resetprop "$1" "$2" 2>/dev/null
else
setprop "$1" "$2" 2>/dev/null
fi
}

------------------------------------------------------------

WAIT FOR BOOT

------------------------------------------------------------

until [ "$(getprop sys.boot_completed)" = "1" ]; do
sleep 5
done

sleep 15

log_msg "=============================================="
log_msg "YAYANG PROJECT OVER POWER v7.1 STARTING"
log_msg "=============================================="

------------------------------------------------------------

HARDWARE DETECTION

------------------------------------------------------------

SOC_INFO="$(
getprop ro.soc.manufacturer
getprop ro.soc.model
getprop ro.board.platform
getprop ro.hardware
)"

SOC_LOWER="$(echo "$SOC_INFO" | tr '[:upper:]' '[:lower:]')"

case "$SOC_LOWER" in
qualcomm|qcom|snapdragon|msm|sm[0-9])
SOC_TYPE="QUALCOMM"
;;
mediatek|mt[0-9]|dimensity|helio)
SOC_TYPE="MEDIATEK"
;;
exynos)
SOC_TYPE="EXYNOS"
;;
unisoc|spreadtrum|ums)
SOC_TYPE="UNISOC"
;;
*)
SOC_TYPE="UNKNOWN"
;;
esac

CPU_CORES="$(grep -c '^processor' /proc/cpuinfo)"
LAST_CPU=$((CPU_CORES - 1))

MEM_KB="$(awk '/MemTotal/ {print $2}' /proc/meminfo)"
MEM_GB=$((MEM_KB / 1024 / 1024))

SDK="$(getprop ro.build.version.sdk)"

------------------------------------------------------------

GPU DETECTION

------------------------------------------------------------

if [ -d /sys/class/kgsl/kgsl-3d0 ]; then
GPU_TYPE="ADRENO"
elif find /sys/class/devfreq -maxdepth 1 2>/dev/null |
grep -qiE 'mali|gpu'; then
GPU_TYPE="MALI"
else
GPU_TYPE="UNKNOWN"
fi

log_msg "SOC=$SOC_TYPE"
log_msg "GPU=$GPU_TYPE"
log_msg "CPU=${CPU_CORES} cores"
log_msg "RAM=${MEM_GB}GB"
log_msg "SDK=$SDK"

============================================================

CPU FUNCTIONS

============================================================

cpu_online_all() {

for CPU in /sys/devices/system/cpu/cpu[0-9]*; do
    [ -e "$CPU/online" ] &&
        write_node "$CPU/online" 1
done

}

cpu_max_freq() {

for POLICY in /sys/devices/system/cpu/cpufreq/policy*; do

    [ -d "$POLICY" ] || continue

    MAX="$(cat "$POLICY/cpuinfo_max_freq" 2>/dev/null)"

    [ -n "$MAX" ] &&
        write_node "$POLICY/scaling_max_freq" "$MAX"

done

}

set_cpu_governor() {

TARGET="$1"

for POLICY in /sys/devices/system/cpu/cpufreq/policy*; do

    [ -d "$POLICY" ] || continue

    GOVFILE="$POLICY/scaling_governor"
    AVAIL="$POLICY/scaling_available_governors"

    [ -f "$AVAIL" ] || continue

    GOVS="$(cat "$AVAIL")"

    if echo "$GOVS" | grep -qw "$TARGET"; then
        write_node "$GOVFILE" "$TARGET"

    elif echo "$GOVS" | grep -qw schedutil; then
        write_node "$GOVFILE" schedutil

    fi
done

}

============================================================

CPUSET ENGINE

============================================================

set_cpuset_full() {

write_node /dev/cpuset/top-app/cpus "0-$LAST_CPU"
write_node /dev/cpuset/foreground/cpus "0-$LAST_CPU"

}

set_cpuset_dynamic() {

if [ "$CPU_CORES" -ge 8 ]; then

    MID=$((CPU_CORES / 2))

    write_node /dev/cpuset/top-app/cpus "${MID}-${LAST_CPU}"
    write_node /dev/cpuset/foreground/cpus "0-${LAST_CPU}"

else

    write_node /dev/cpuset/top-app/cpus "0-${LAST_CPU}"
    write_node /dev/cpuset/foreground/cpus "0-${LAST_CPU}"

fi

}

============================================================

GPU ENGINE

============================================================

gpu_full_power() {

# ---------------- ADRENO ----------------

if [ "$GPU_TYPE" = "ADRENO" ]; then

    KGSL="/sys/class/kgsl/kgsl-3d0"

    GOVS="$(cat "$KGSL/devfreq/available_governors" 2>/dev/null)"

    if echo "$GOVS" | grep -qw performance; then
        write_node "$KGSL/devfreq/governor" performance
    fi

    MAX_GPU="$(cat "$KGSL/devfreq/max_freq" 2>/dev/null)"

    [ -n "$MAX_GPU" ] &&
        write_node "$KGSL/devfreq/max_freq" "$MAX_GPU"

    write_node "$KGSL/force_clk_on" 1
    write_node "$KGSL/force_bus_on" 1
    write_node "$KGSL/force_rail_on" 1

fi

# ---------------- MALI ----------------

if [ "$GPU_TYPE" = "MALI" ]; then

    for GPU in /sys/class/devfreq/*; do

        [ -d "$GPU" ] || continue

        REAL="$(readlink -f "$GPU")"

        echo "$REAL" |
            grep -qiE 'mali|gpu' || continue

        GOVS="$(cat "$GPU/available_governors" 2>/dev/null)"

        if echo "$GOVS" | grep -qw performance; then
            write_node "$GPU/governor" performance
        fi

        MAX_GPU="$(cat "$GPU/max_freq" 2>/dev/null)"

        [ -n "$MAX_GPU" ] &&
            write_node "$GPU/max_freq" "$MAX_GPU"

    done

fi

}

gpu_dynamic() {

if [ "$GPU_TYPE" = "ADRENO" ]; then

    KGSL="/sys/class/kgsl/kgsl-3d0"

    GOVS="$(cat "$KGSL/devfreq/available_governors" 2>/dev/null)"

    if echo "$GOVS" | grep -qw msm-adreno-tz; then
        write_node "$KGSL/devfreq/governor" msm-adreno-tz
    fi

    write_node "$KGSL/force_clk_on" 0
    write_node "$KGSL/force_bus_on" 0
    write_node "$KGSL/force_rail_on" 0
fi

if [ "$GPU_TYPE" = "MALI" ]; then

    for GPU in /sys/class/devfreq/*; do

        [ -d "$GPU" ] || continue

        REAL="$(readlink -f "$GPU")"

        echo "$REAL" |
            grep -qiE 'mali|gpu' || continue

        GOVS="$(cat "$GPU/available_governors" 2>/dev/null)"

        if echo "$GOVS" | grep -qw simple_ondemand; then
            write_node "$GPU/governor" simple_ondemand

        elif echo "$GOVS" | grep -qw schedutil; then
            write_node "$GPU/governor" schedutil
        fi

    done

fi

}

============================================================

MEMORY ENGINE

============================================================

memory_performance() {

write_node /proc/sys/vm/swappiness 100
write_node /proc/sys/vm/page-cluster 0

write_node /proc/sys/vm/dirty_ratio 15
write_node /proc/sys/vm/dirty_background_ratio 5

write_node /proc/sys/vm/vfs_cache_pressure 100

}

memory_full_power() {

write_node /proc/sys/vm/swappiness 80
write_node /proc/sys/vm/page-cluster 0

write_node /proc/sys/vm/dirty_ratio 10
write_node /proc/sys/vm/dirty_background_ratio 5

}

============================================================

I/O ENGINE

============================================================

optimize_io() {

for QUEUE in /sys/block/*/queue; do

    [ -d "$QUEUE" ] || continue

    DEVICE="$(basename "$(dirname "$QUEUE")")"

    case "$DEVICE" in
        loop*|ram*|zram*)
            continue
            ;;
    esac

    SCHED="$(cat "$QUEUE/scheduler" 2>/dev/null)"

    if echo "$SCHED" | grep -q "mq-deadline"; then
        write_node "$QUEUE/scheduler" mq-deadline

    elif echo "$SCHED" | grep -q "deadline"; then
        write_node "$QUEUE/scheduler" deadline

    elif echo "$SCHED" | grep -q "none"; then
        write_node "$QUEUE/scheduler" none
    fi

    write_node "$QUEUE/read_ahead_kb" 128
    write_node "$QUEUE/add_random" 0
    write_node "$QUEUE/iostats" 0

done

}

============================================================

NETWORK ENGINE

============================================================

optimize_network() {

write_node /proc/sys/net/ipv4/tcp_fastopen 3
write_node /proc/sys/net/ipv4/tcp_syncookies 1
write_node /proc/sys/net/ipv4/tcp_no_metrics_save 1

write_node /proc/sys/net/core/netdev_max_backlog 4096
write_node /proc/sys/net/core/somaxconn 1024

}

============================================================

RENDERING ENGINE

============================================================

optimize_rendering() {

set_prop debug.hwui.renderer skiavk
set_prop debug.renderengine.backend skiaglthreaded

set_prop debug.hwui.use_partial_updates true
set_prop debug.hwui.render_dirty_regions true

set_prop debug.sf.enable_layer_caching true
set_prop debug.sf.predict_hwc_composition_strategy 1

}

============================================================

TEMPERATURE DETECTION

============================================================

get_temperature() {

MAX_TEMP=0

for ZONE in /sys/class/thermal/thermal_zone*/temp; do

    [ -r "$ZONE" ] || continue

    TEMP="$(cat "$ZONE" 2>/dev/null)"

    case "$TEMP" in
        ''|*[!0-9]*)
            continue
            ;;
    esac

    # Convert millidegree to Celsius
    if [ "$TEMP" -gt 1000 ]; then
        TEMP=$((TEMP / 1000))
    fi

    # Ignore impossible sensor values
    if [ "$TEMP" -gt "$MAX_TEMP" ] &&
       [ "$TEMP" -lt 120 ]; then
        MAX_TEMP="$TEMP"
    fi

done

echo "$MAX_TEMP"

}

============================================================

BATTERY DETECTION

============================================================

get_battery() {

cat /sys/class/power_supply/battery/capacity 2>/dev/null

}

is_charging() {

STATUS="$(
    cat /sys/class/power_supply/battery/status 2>/dev/null
)"

case "$STATUS" in
    Charging|Full)
        return 0
        ;;
    *)
        return 1
        ;;
esac

}

============================================================

FOREGROUND APP DETECTION

============================================================

get_foreground_app() {

dumpsys activity activities 2>/dev/null |
    grep -m1 'mResumedActivity' |
    sed -n 's/.* [^ ]*\/[^ ]*.*/\1/p' |
    cut -d/ -f1

}

============================================================

GAME DETECTION

Add package names to:

$MODDIR/gamelist.txt

Example:

com.tencent.ig

com.mobile.legends

com.dts.freefireth

============================================================

is_game_running() {

APP="$(get_foreground_app)"

[ -n "$APP" ] || return 1
[ -f "$MODDIR/gamelist.txt" ] || return 1

grep -Fxq "$APP" "$MODDIR/gamelist.txt"

}

============================================================

FULL POWER PROFILE

============================================================

apply_full_power() {

CURRENT="$(cat "$STATEFILE" 2>/dev/null)"

[ "$CURRENT" = "FULL_POWER" ] && return

log_msg "MODE => FULL_POWER"

cpu_online_all
cpu_max_freq
set_cpu_governor performance

set_cpuset_full

gpu_full_power

memory_full_power

# Top-app boost
write_node /dev/stune/top-app/schedtune.boost 20
write_node /dev/stune/top-app/schedtune.prefer_idle 1

write_node /dev/cpuctl/top-app/cpu.uclamp.min 30
write_node /dev/cpuctl/top-app/cpu.uclamp.max max

echo FULL_POWER > "$STATEFILE"

}

============================================================

PERFORMANCE PROFILE

============================================================

apply_performance() {

CURRENT="$(cat "$STATEFILE" 2>/dev/null)"

[ "$CURRENT" = "PERFORMANCE" ] && return

log_msg "MODE => PERFORMANCE"

cpu_online_all
cpu_max_freq

set_cpu_governor schedutil
set_cpuset_dynamic

gpu_dynamic

memory_performance

write_node /dev/stune/top-app/schedtune.boost 10
write_node /dev/stune/top-app/schedtune.prefer_idle 1

echo PERFORMANCE > "$STATEFILE"

}

============================================================

CHARGING PERFORMANCE PROFILE

============================================================

apply_charging() {

CURRENT="$(cat "$STATEFILE" 2>/dev/null)"

[ "$CURRENT" = "CHARGING" ] && return

log_msg "MODE => CHARGING"

cpu_online_all
cpu_max_freq

set_cpu_governor schedutil
set_cpuset_dynamic

gpu_dynamic

memory_performance

echo CHARGING > "$STATEFILE"

}

============================================================

COOL / SAFETY PROFILE

Does NOT disable thermal protection.

Instead it stops forced full-power settings.

============================================================

apply_cool() {

CURRENT="$(cat "$STATEFILE" 2>/dev/null)"

[ "$CURRENT" = "COOL" ] && return

log_msg "MODE => COOL"

set_cpu_governor schedutil
set_cpuset_dynamic

gpu_dynamic

write_node /dev/stune/top-app/schedtune.boost 0

echo COOL > "$STATEFILE"

}

============================================================

INITIAL SYSTEM OPTIMIZATION

============================================================

cpu_online_all
cpu_max_freq

optimize_io
optimize_network
optimize_rendering

memory_performance

KSM

if [ -d /sys/kernel/mm/ksm ]; then

write_node /sys/kernel/mm/ksm/run 1
write_node /sys/kernel/mm/ksm/pages_to_scan 100
write_node /sys/kernel/mm/ksm/sleep_millisecs 500

fi

Activity Manager

cmd device_config put activity_manager 
max_cached_processes 256 2>/dev/null

cmd device_config put activity_manager 
max_phantom_processes 2147483647 2>/dev/null

Reduce kernel console spam

write_node /proc/sys/kernel/printk "0 0 0 0"

============================================================

ADAPTIVE ENGINE

Temperature:

>= 50 C = COOL

Game:

FULL_POWER

Charging:

CHARGING

Normal:

PERFORMANCE

============================================================

log_msg "Adaptive Engine started"

while true; do

TEMP="$(get_temperature)"
BATTERY="$(get_battery)"
APP="$(get_foreground_app)"

[ -z "$TEMP" ] && TEMP=0
[ -z "$BATTERY" ] && BATTERY=0

# ---------------- HIGH TEMPERATURE ----------------

if [ "$TEMP" -ge 50 ]; then

    apply_cool

# ---------------- GAME DETECTED ----------------

elif is_game_running; then

    apply_full_power

# ---------------- CHARGING ----------------

elif is_charging; then

    apply_charging

# ---------------- NORMAL ----------------

else

    apply_performance

fi

sleep 10

done